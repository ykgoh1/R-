#Ng Zhe Shen - TP071625

#Importing the .csv file
dataset = read.csv("C:\\Users\\zhesh\\OneDrive\\Desktop\\PFDA Assignment\\credit_risk.csv", header=TRUE)
dataset

#Renaming the first 6 columns' header
colnames(dataset)[1:6]=c("No.","Checking_Status","Duration(Year)","Credit_History","Purpose","Credit_Amount(RM)")
# renaming columns 7-11 (G-K)
names(dataset)[7:11] = 
  c("The_Statuses_of_Savings","Status_of_Employment(year_range)",
    "Installment_Commitment_Count","Confidential_Personal_Status",
    "Other_Party(type)")
# renaming columns 12-16 (L-P)
names(dataset)[12:16] = 
  c("Residence_Since","Property_Magnitude","Age","Other_Payment_Plans","Housing")
#renaming columns 17-22 (Q -V)
names(dataset)[17:22]=
  c("Existing_Credits","Job","Num_Dependents","Own_Telephone","Foreign_Worker","Class")
names(dataset)

#Converting Duration(Year) column to hold only integer value
dataset$`Duration(Year)`=as.integer(dataset$`Duration(Year)`)
# convert to integer "Installment_Commitment_Count" (assignment_file[9])
dataset$Installment_Commitment_Count = as.integer(dataset$Installment_Commitment_Count)
# convert to integer "Residence_Since"
dataset$Residence_Since = as.integer(dataset$Residence_Since)
# convert to integer "Age"
dataset$Age = as.integer(dataset$Age)
#Existing_Credits = convert to integer 
dataset$Existing_Credits = as.integer(dataset$Existing_Credits)
# Num_Dependents = convert to integer
dataset$Num_Dependents = as.integer(dataset$Num_Dependents)


#Rounding the Credit_Amount(RM) column to 2 decimal places
dataset$`Credit_Amount(RM)`=round(dataset$`Credit_Amount(RM)`,2)
dataset$`Credit_Amount(RM)`

# fix the typo in Credit_History column ("no credits/all paid" -> "no credits")
dataset[dataset=="no credits/all paid"] = "no credits"
# fix the typo in the dataset ( "500<=X<10000" -> "500<=X<1000") to make it make sense :D
dataset[dataset=="500<=X<10000"] = "500<=X<1000"

# Function to get the mode
get_mode <- function(v) {
  uniq_v <- unique(v[!(is.na(v) | v == "")])  # Remove NA and blank spaces
  uniq_v[which.max(tabulate(match(v, uniq_v)))]  # Find the most frequent value
}
# Replace both NA values and blank spaces with the mode
dataset$Other_Payment_Plans[is.na(dataset$Other_Payment_Plans) | dataset$Other_Payment_Plans == ""] = get_mode(dataset$Other_Payment_Plans)

View(dataset)
str(dataset)

head(dataset)
tail(dataset)
names(dataset)
ncol(dataset)
nrows(dataset)
summary((dataset))

#Pre-processing column 2 - 6
factor(dataset$Checking_Status) #Categories in Checking_Status column
nlevels(factor(dataset$Checking_Status)) #Number of categories in Checking_Status column is 4
summary(dataset$`Duration(Year)`) #Summary of Duration(Year) column
factor(dataset$Credit_History) #Categories in Credit_History column
nlevels(factor(dataset$Credit_History)) #Number of categories in Credit_History column is 5
factor(dataset$Purpose) #Categories in Purpose column
nlevels(factor(dataset$Purpose)) #Number of categories in Purpose column is 10
summary(dataset$`Credit_Amount(RM)`) #Summary of Credit_Amount(RM) column

#------------------------------Data Exploration
#Credit_Amount(RM) <= 4000 -> Status_of_Employment(year_range) >= 7 -> 
#The_Statuses_of_Savings == "no known savings" -> Credit_History == "critical/order existing credit"
summary(dataset$`Credit_Amount(RM)`)
factor(dataset$`Status_of_Employment(year_range)`)
factor(dataset$The_Statuses_of_Savings)
factor(dataset$Credit_History)

nrow(dataset[dataset$Class=="good", ]) #3000 rows of "good" class

nrow(dataset[(dataset$Class=="good") & (dataset$`Credit_Amount(RM)`<=4000), ]) #2406 rows (Majority)

nrow(dataset[(dataset$Class=="good") & (dataset$`Credit_Amount(RM)`<=4000) & 
               (dataset$`Status_of_Employment(year_range)`==">=7"), ])  #668 rows(Minority)

#Opposite of Status_of_Employment(year_range)`==">=7"
nrow(dataset[(dataset$Class=="good") & (dataset$`Credit_Amount(RM)`<=4000) & 
               (dataset$`Status_of_Employment(year_range)`!=">=7"), ]) #1738 rows(Majority)

nrow(dataset[(dataset$Class=="good") & (dataset$`Credit_Amount(RM)`<=4000) & 
               (dataset$`Status_of_Employment(year_range)`!=">=7") &
               (dataset$The_Statuses_of_Savings=="no known savings"), ]) #277 rows(Minority)

#Opposite of The_Statuses_of_Savings=="no known savings"
nrow(dataset[(dataset$Class=="good") & (dataset$`Credit_Amount(RM)`<=4000) & 
               (dataset$`Status_of_Employment(year_range)`!=">=7") &
               (dataset$The_Statuses_of_Savings!="no known savings"), ]) #1461 rows(Majority)

nrow(dataset[(dataset$Class=="good") & (dataset$`Credit_Amount(RM)`<=4000) & 
               (dataset$`Status_of_Employment(year_range)`!=">=7") &
               (dataset$The_Statuses_of_Savings!="no known savings") & 
               (dataset$Credit_History=="critical/order existing credit"), ]) #450 rows(Minority)

#Opposite of Credit_History=="critical/order existing credit"
nrow(dataset[(dataset$Class=="good") & (dataset$`Credit_Amount(RM)`<=4000) & 
               (dataset$`Status_of_Employment(year_range)`!=">=7") &
               (dataset$The_Statuses_of_Savings!="no known savings") & 
               (dataset$Credit_History!="critical/order existing credit"), ]) #1011 rows(Majority)
#1011/3000 x 100% = 33.7% (Prediction accuracy is too low)

#Conclusion: The initial hypothesis is wrong. Modifications must be done on 
#1)Status_of_Employment(year_range), 2) The_Statuses_of_Savings, 3) Credit_History

#New Hypothesis: 
#Credit_Amount(RM) <= 6000 -> Age <= 60 -> 
#Foreign_Worker == "yes" -> Status_of_Employment(year_range) != "unemployed"
summary(dataset$`Credit_Amount(RM)`)
summary(dataset$Age)
factor(dataset$Foreign_Worker)
factor(dataset$`Status_of_Employment(year_range)`)

nrow(dataset[dataset$Class=="good", ]) #3000 rows

nrow(dataset[(dataset$Class=="good") & 
               (dataset$`Status_of_Employment(year_range)`!="unemployed"), ]) #2824 rows

nrow(dataset[(dataset$Class=="good") & 
               (dataset$`Status_of_Employment(year_range)`!="unemployed") &
               (dataset$Age<=60), ]) #2710 rows

nrow(dataset[(dataset$Class=="good") & 
               (dataset$`Status_of_Employment(year_range)`!="unemployed") &
               (dataset$Age<=60) & 
               (dataset$Foreign_Worker=="yes"), ]) #2579 rows

nrow(dataset[(dataset$Class=="good") & 
               (dataset$`Status_of_Employment(year_range)`!="unemployed") &
               (dataset$Age<=60) & 
               (dataset$Foreign_Worker=="yes") &
               (dataset$`Credit_Amount(RM)`<=6000), ]) #2294 rows

#2294/3000 x 100% = 76.47% Accuracy

#---------------------------------------DATA VISUALIZATION
install.packages("tibble")

#Filter data for Class == "good"
good = dataset[dataset$Class == "good", ]

#Calculate the number of rows for Credit_Amount(RM) <=4000 and >4000
count = c(sum(good$`Credit_Amount(RM)`<=4000), sum(good$`Credit_Amount(RM)`>4000))

#Use tibble to visualize the Credit_Amount(RM) column in a table form
library(tibble)
tibble(`Credit Amount(RM)` = c("<=4000",">4000"), 
       Count = count)

#Calculating the percentage
percentage = round(count/sum(count)*100, 1)
library(ggplot2)
#Pie chart for Credit_Amount(RM)
pie(count, label=paste(c("<=4000",">4000")," (",percentage,"%",")",sep=""),
    radius=1,main="Credit_Amount(RM) in Good",col=c("green","red"))

#Determine the highest frequency bar
highest_status <- names(table(
  good$`Status_of_Employment(year_range)`))[which.max(table(good$`Status_of_Employment(year_range)`))]
#Plot chart for Status_of_Employment(year_range)
ggplot(good, aes(x = `Status_of_Employment(year_range)`)) +
  geom_bar(aes(fill = ifelse(`Status_of_Employment(year_range)` == ">=7", ">=7",
                      ifelse(`Status_of_Employment(year_range)` == highest_status, "highest", "other")))) +
  scale_fill_manual(values = c(">=7" = "red", "highest" = "yellow", "other" = "grey")) +
  geom_text(stat = "count", aes(label = after_stat(count)), vjust = 2) +
  labs(title = "Distribution of Status of Employment (Year Range) for Class 'Good'",
       fill = "Legend",
       x = "Status of Employment",
       y = "Frequency")

#Determine the highest value
highest_status = names(table(good$The_Statuses_of_Savings))[which.max(table(good$The_Statuses_of_Savings))]
# Create a dot plot
ggplot(good, aes(x = The_Statuses_of_Savings)) +
  stat_count(geom = "point", aes(y = after_stat(count),
  color = ifelse(The_Statuses_of_Savings == "no known savings", "no known savings",
          ifelse(The_Statuses_of_Savings == highest_status, "highest", "other"))),
  size = 5) +
  scale_color_manual(values = c("no known savings"="cyan", "highest"="yellow", "other"="grey")) +
  # Add count text labels above each dot
  stat_count(geom = "text", aes(label = after_stat(count), y = after_stat(count) + 0.5),
             color = "black", size = 3, fontface = "bold") +
  # Additional settings to expand the view
  expand_limits(y=0) +
  labs(title = "Distribution of Status of Savings for Class 'Good'",
       color = "Legend",
       x = "Status of Savings",
       y = "Frequency") +
  # Use theme_minimal and customize plot theme with theme()
  theme_minimal() +
  theme(
    panel.grid.major = element_line(color = "grey90", linetype = "dashed"),
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5, color = "darkblue"),
    axis.text.x = element_text(angle = 45, hjust = 1, color = "black", size = 10)
  )

# Create a frequency table
credit_history_counts = as.data.frame(table(good$Credit_History))
colnames(credit_history_counts) = c("Credit_History", "Count")
credit_history_counts$Percentage = round(credit_history_counts$Count / 
                                           sum(credit_history_counts$Count)*100,1)
credit_history_counts
#Donut chart
ggplot(credit_history_counts, aes(x = 2, y = Count, fill = Credit_History)) +
  geom_col(width = 1, color = "white") +
  geom_text(aes(label=paste(Count,"\n(",Percentage,"%)",sep="")),position=position_stack(vjust=0.5)) +
  coord_polar(theta = "y") +
  xlim(0.8, 2.5) +
  labs(title = "Distribution of Credit History for Class 'Good'",
       fill = "Credit History") +
  theme_void() +
  theme(legend.position = "right")

#Visualization of Initial Hypothesis
install.packages("VennDiagram")
library(VennDiagram)
initial_hypothesis = nrow(dataset[(dataset$Class=="good") & (dataset$`Credit_Amount(RM)`<=4000) & 
                                    (dataset$`Status_of_Employment(year_range)`=="1<=X<4") &
                                    (dataset$The_Statuses_of_Savings=="<100") & 
                                    (dataset$Credit_History=="existing paid"), ])
#Venn Diagram - Initial Hypothesis vs Total Good Class
draw.pairwise.venn(
  area1 = 3000,         # Total "good" class
  area2 = initial_hypothesis,
  cross.area = initial_hypothesis,
  category = c("Total Good Class", "Hypothesis"),
  fill = c("lightgreen", "blue"),
  lty = "blank",
  cex = 2, cat.cex = 1.5, cat.pos = c(-20, 20), cat.dist = 0.02, scaled = TRUE
)

#Histogram for Age
ggplot(good, aes(x = Age)) + 
  geom_histogram(color = "black", aes(fill = ifelse(Age <= 60, "<=60", ">60"))) +
  scale_fill_manual(values = c("<=60" = "gold", ">60" = "grey")) +
  labs(fill = "Age Range") +
  labs(title = "Distribution of Age",
       x = "Age",
       y = "Count")

#Chi-square to see if the distribution is even
observed = table(good$Age)
chisq.test(observed, p = rep(1/length(observed), length(observed)))

#Class = "good", Credit Amount <= 6000, Credit History == "existing paid"
good_ca_ch = nrow(good[(good$`Credit_Amount(RM)`<=6000) & 
                         (good$Credit_History=="existing paid"), ])
good_ca_ch

#Class = "good", Credit Amount <= 6000, Age <= 60
good_ca_age = nrow(good[(good$`Credit_Amount(RM)`<=6000) & 
                          (good$Age<=60), ])
good_ca_age

#Difference between the two
ch_vs_age = data.frame(Category = c("Credit History == existing paid", "Age <= 60"),
                       Count = c(good_ca_ch, good_ca_age))
ggplot(ch_vs_age, aes(x = Category, y = Count, fill = Category)) +
  geom_bar(stat = "identity", width = 0.4) +
  geom_text(aes(label = Count), vjust =2, color = "black", size = 5) +
  labs(title = "Age <= 60 VS Credit History == existing paid",
       x = "Condition",
       y = "Count") +
  theme(legend.position = "none")

#Final Conclusion
final_conclusion = nrow(good[(good$`Credit_Amount(RM)`<=6000) & 
                                    (good$Age <= 60) &
                                    (good$Foreign_Worker == "yes") & 
                                    (good$`Status_of_Employment(year_range)`!= "unemployed"), ])
final_conclusion

#Venn Diagram for final conclusion
draw.pairwise.venn(
  area1 = 3000,         # Total "good" class
  area2 = final_conclusion,
  cross.area = final_conclusion,
  category = c("Total Good Class", "Final Conclusion"),
  fill = c("lightgreen", "blue"),
  lty = "blank",
  cex = 2, cat.cex = 1.5, cat.pos = c(-20, 20), cat.dist = 0.02, scaled = TRUE
)
