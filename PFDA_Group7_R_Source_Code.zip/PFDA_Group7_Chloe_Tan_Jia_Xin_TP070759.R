#Chloe Tan Jia Xin - TP070759

#Importing the .csv file
dataset = read.csv("C:\\Users\\60105\\Downloads\\credit_risk.csv", header=TRUE)
dataset

#Renaming the first 6 columns' header
colnames(dataset)[1:6]=c("No.","Checking_Status","Duration(Year)","Credit_History","Purpose","Credit_Amount(RM)")
# renaming columns 7-11 (G-K)
names(dataset)[7:11] = 
  c("The_Statuses_of_Savings","Status_of_Employment(year_range)",
    "Installment_Commitment_Count","Confidential_Personal_Status",
    "Other_Party(type)")
# renaming columns 12-16 (L-P)
names(dataset)[12:16] = 
  c("Residence_Since","Property_Magnitude","Age","Other_Payment_Plans","Housing")
#renaming columns 17-22 (Q -V)
names(dataset)[17:22]=
  c("Existing_Credits","Job","Num_Dependents","Own_Telephone","Foreign_Worker","Class")
names(dataset)

#Converting Duration(Year) column to hold only integer value
dataset$`Duration(Year)`=as.integer(dataset$`Duration(Year)`)
# convert to integer "Installment_Commitment_Count" (assignment_file[9])
dataset$Installment_Commitment_Count = as.integer(dataset$Installment_Commitment_Count)
# convert to integer "Residence_Since"
dataset$Residence_Since = as.integer(dataset$Residence_Since)
# convert to integer "Age"
dataset$Age = as.integer(dataset$Age)
#Existing_Credits = convert to integer 
dataset$Existing_Credits = as.integer(dataset$Existing_Credits)
# Num_Dependents = convert to integer
dataset$Num_Dependents = as.integer(dataset$Num_Dependents)


#Rounding the Credit_Amount(RM) column to 2 decimal places
dataset$`Credit_Amount(RM)`=round(dataset$`Credit_Amount(RM)`,2)
dataset$`Credit_Amount(RM)`

# fix the typo in Credit_History column ("no credits/all paid" -> "no credits")
dataset[dataset=="no credits/all paid"] = "no credits"
# fix the typo in the dataset ( "500<=X<10000" -> "500<=X<1000") to make it make sense :D
dataset[dataset=="500<=X<10000"] = "500<=X<1000"

# Function to get the mode
get_mode <- function(v) {
  uniq_v <- unique(v[!(is.na(v) | v == "")])  # Remove NA and blank spaces
  uniq_v[which.max(tabulate(match(v, uniq_v)))]  # Find the most frequent value
}
# Replace both NA values and blank spaces with the mode
dataset$Other_Payment_Plans[is.na(dataset$Other_Payment_Plans) | dataset$Other_Payment_Plans == ""] = get_mode(dataset$Other_Payment_Plans)

View(dataset)
str(dataset)

head(dataset)
tail(dataset)
names(dataset)
ncol(dataset)
nrows(dataset)
summary((dataset))

#Pre-processing column 2 - 6
factor(dataset$Checking_Status) #Categories in Checking_Status column
nlevels(factor(dataset$Checking_Status)) #Number of categories in Checking_Status column is 4
summary(dataset$`Duration(Year)`) #Summary of Duration(Year) column
factor(dataset$Credit_History) #Categories in Credit_History column
nlevels(factor(dataset$Credit_History)) #Number of categories in Credit_History column is 5
factor(dataset$Purpose) #Categories in Purpose column
nlevels(factor(dataset$Purpose)) #Number of categories in Purpose column is 10
summary(dataset$`Credit_Amount(RM)`) #Summary of Credit_Amount(RM) column

#Pre-processing column 12 - 16
summary(dataset$Residence_Since)
factor(dataset$Property_Magnitude)
nlevels(factor(dataset$Property_Magnitude))
summary(dataset$`Age`)
factor(dataset$Other_Payment_Plans)
nlevels(factor(dataset$Other_Payment_Plans))
factor(dataset$Housing)
nlevels(factor(dataset$Housing))



# Initial Hypothesis
#Credit Amount
# Class == "good"
dataset[dataset$Class=="good", ]
nrow(dataset[dataset$Class=="good",] ) #3000

# Load required libraries
library(ggplot2)
library(dplyr)

# Calculate the counts for "good" class with Credit_Amount(RM) <= 4000 and > 4000
count_4000_or_less <- nrow(dataset %>% filter(Class == "good" & `Credit_Amount(RM)` <= 4000))#2406
count_above_4000 <- nrow(dataset %>% filter(Class == "good" & `Credit_Amount(RM)` > 4000))#594

# Create a new column for categorizing Credit_Amount(RM) into "<= 4000" and "> 4000"
dataset <- dataset %>%
  mutate(Credit_Amount_Category = ifelse(`Credit_Amount(RM)` <= 4000, "<= 4000", "> 4000"))

# Create the box plot using ggplot2
ggplot(dataset %>% filter(Class == "good"), aes(x = Credit_Amount_Category, y = `Credit_Amount(RM)`, fill = Credit_Amount_Category)) +
  geom_boxplot() +                              # Box plot
  labs(title = "Distribution of Credit Amount(RM) for Class 'Good'",
       x = "Credit Amount Category", y = "Credit Amount (RM)") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, face = "bold")) +  
  scale_fill_manual(values = c("<= 4000" = "skyblue", "> 4000" = "orange"))  


#Status of Employment
# Class == "good"
nrow(dataset[dataset$Class=="good",] ) #3000

# Load required libraries
library(ggplot2)
library(dplyr)

# Calculate the counts for each employment status
count_less_than_1 <- nrow(dataset[(dataset$Class == "good") & (dataset$`Status_of_Employment(year_range)` == "<1"),]) # 408
count_7_or_more <- nrow(dataset[(dataset$Class == "good") & (dataset$`Status_of_Employment(year_range)` == ">=7"),]) # 827
count_1_to_4 <- nrow(dataset[(dataset$Class == "good") & (dataset$`Status_of_Employment(year_range)` == "1<=X<4"),]) # 1011
count_4_to_7 <- nrow(dataset[(dataset$Class == "good") & (dataset$`Status_of_Employment(year_range)` == "4<=X<7"),]) # 578
count_unemployed <- nrow(dataset[(dataset$Class == "good") & (dataset$`Status_of_Employment(year_range)` == "unemployed"),]) # 176

# Create a data frame with the counts for each employment status
employment_data <- data.frame(
  Category = c("<1 year", ">=7 years", "1<=X<4 years", "4<=X<7 years", "Unemployed"),
  Count = c(count_less_than_1, count_7_or_more, count_1_to_4, count_4_to_7, count_unemployed)
)

# Create the donut chart
ggplot(employment_data, aes(x = 2, y = Count, fill = Category)) +
  geom_bar(stat = "identity", width = 1) +           # Bar chart
  coord_polar("y", start = 0) +                      # Convert to polar coordinates (circular)
  labs(title = "Distribution of Employment Status for Class 'Good'") +
  theme_void() +                                     # Remove axis and grid
  theme(plot.title = element_text(hjust = 0.5, face = "bold")) + 
  
  # Set x aesthetic to create a hole in the center (donut effect)
  scale_x_continuous(limits = c(1, 2.5)) +            
  
  # Custom colors for each segment
  scale_fill_manual(values = c("<1 year" = "skyblue", 
                               ">=7 years" = "orange", 
                               "1<=X<4 years" = "purple", 
                               "4<=X<7 years" = "green", 
                               "Unemployed" = "red"))


# Status of Savings
# Class == "good"
nrow(dataset[dataset$Class=="good",] ) #3000

# Load required libraries
library(ggplot2)
library(dplyr)

# Calculate the counts for each category of 'The_Statuses_of_Savings' for 'good' class
count_lessthan_100 <- nrow(dataset %>% filter(Class == "good" & `The_Statuses_of_Savings` == "<100"))
count_1000_or_more <- nrow(dataset %>% filter(Class == "good" & `The_Statuses_of_Savings` == ">=1000"))
count_100_to_500 <- nrow(dataset %>% filter(Class == "good" & `The_Statuses_of_Savings` == "100<=X<500"))
count_500_to_1000 <- nrow(dataset %>% filter(Class == "good" & `The_Statuses_of_Savings` == "500<=X<1000"))
count_no_savings <- nrow(dataset %>% filter(Class == "good" & `The_Statuses_of_Savings` == "no known savings"))


# Create a data frame with the counts for each savings status
savings_data <- data.frame(
  Status = c("<100", ">=1000", "100<=X<500", "500<=X<1000", "no known savings"),
  Count = c(1567, 186, 340, 209, 698)
)

# Create the bar chart
ggplot(savings_data, aes(x = Status, y = Count, fill = Status)) +
  geom_bar(stat = "identity") +  # Bar chart with heights proportional to count
  labs(title = "Distribution of Savings Status for Class 'Good'",
       x = "Savings Status", y = "Count") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, face = "bold")) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +  
  scale_fill_manual(values = c("<100" = "skyblue", ">=1000" = "orange", 
                               "100<=X<500" = "green", "500<=X<1000" = "purple",
                               "no known savings" = "red"))


#Credit History
# Load required libraries
library(ggplot2)

# Calculate the counts for each category of 'Credit_History' for 'good' class
count_all_paid <- nrow(dataset %>% filter(Class == "good" & `Credit_History` == "all paid"))
count_critical_order_existing_credit <- nrow(dataset %>% filter(Class == "good" & `Credit_History` == "critical/order existing credit"))
count_delayed_previously <- nrow(dataset %>% filter(Class == "good" & `Credit_History` == "delayed previously"))
count_existing_paid <- nrow(dataset %>% filter(Class == "good" & `Credit_History` == "existing paid"))
count_no_credits <- nrow(dataset %>% filter(Class == "good" & `Credit_History` == "no credits"))

# Create a data frame with the counts for each Credit_History category for Class "good"
credit_history_data <- data.frame(
  Credit_History = c("all paid", "critical/order existing credit", "delayed previously", 
                     "existing paid", "no credits"),
  Count = c(99, 1038, 279, 1513, 71)
)

# Create the dot plot with discrete colors
ggplot(credit_history_data, aes(x = Count, y = Credit_History, color = Credit_History)) +
  geom_point(size = 5) +                                   
  labs(title = "Distribution of Credit History for Class 'Good'",
       x = "Count", y = "Credit History") +
  scale_color_manual(values = c("all paid" = "skyblue", 
                                "critical/order existing credit" = "orange", 
                                "delayed previously" = "green",
                                "existing paid" = "purple", 
                                "no credits" = "red")) +  
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, face = "bold")) +
  theme(axis.text.y = element_text(size = 10))              



# FINAL CONCLUSION FOR FIRST HYPOTHESIS
nrow(dataset[(dataset$Class=="good") & (dataset$The_Statuses_of_Savings=="<100") & 
               (dataset$`Credit_Amount(RM)`<=4000) & (dataset$`Status_of_Employment(year_range)`=="1<=X<4") & 
               (dataset$`Credit_History` == "existing paid"),]) 
# Load required library
library(ggplot2)

# Create a data frame for plotting
bar_data <- data.frame(
  Category = c("Filtered Data (267)", "Other Data (5733)"),
  Count = c(267, 6000 - 267)
)

# Create the pie chart using ggplot2
ggplot(bar_data, aes(x = "", y = Count, fill = Category)) +
  geom_bar(stat = "identity", width = 1) +        # Bar chart
  coord_polar("y", start = 0) +                   # Convert to pie chart
  labs(title = "Total Good Class") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),  # Center the title
    axis.title.x = element_blank(),                     # Remove x-axis title
    axis.title.y = element_blank(),                     # Remove y-axis title
    axis.text = element_blank(),                        # Remove axis text
    axis.ticks = element_blank(),                       # Remove axis ticks
    panel.grid = element_blank()                        # Remove grid lines
  ) +
  scale_fill_manual(values = c("Filtered Data (267)" = "red", "Other Data (5733)" = "lightblue"))  


#Foreign_Worker
# Load necessary library
library(ggplot2)

# Count rows where Foreign_Worker == "yes" and Class == "good"
count_yes <- nrow(dataset[dataset$Foreign_Worker == "yes" & dataset$Class == "good", ]) #2868

# Count rows where Foreign_Worker == "no" and Class == "good"
count_no <- nrow(dataset[dataset$Foreign_Worker == "no" & dataset$Class == "good", ]) #132

# Create a data frame with the counts
counts_df <- data.frame(
  Foreign_Worker = c("yes", "no"),
  Count = c(count_yes, count_no)
)

# Display the counts
print(counts_df)

# Create a horizontal bar chart
ggplot(data = counts_df, aes(x = Count, y = Foreign_Worker, fill = Foreign_Worker)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = Count), hjust = -0.2) +  
  labs(title = "Foreign_Worker Status in Class == 'Good'", x = "Count", y = "Foreign Worker Status") +
  scale_fill_manual(values = c("lightblue", "lightgreen")) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, face = "bold")) 



#Compare Foreign_Worker and The_Statuses_Of_Savings in the Class == "good"
# Load necessary library
library(ggplot2)

# Count for Foreign_Worker and Statuses_Of_Savings
count_foreign_worker <- nrow(dataset[dataset$Class == "good" & dataset$`Credit_Amount(RM)` <= 6000 
                                     & dataset$Age <= 60 & dataset$Foreign_Worker == "yes", ])
count_savings_status <- nrow(dataset[dataset$Class == "good" & dataset$`Credit_Amount(RM)` <= 6000 
                                     & dataset$Age <= 60 & dataset$The_Statuses_of_Savings == "no known savings", ])

# Create data frame with the counts
count_data <- data.frame(
  Category = c("Foreign_Worker == 'yes'", "Statuses_Of_Savings == 'no known savings'"),
  Count = c(count_foreign_worker, count_savings_status)
)

# Create the bar chart
ggplot(count_data, aes(x = Category, y = Count, fill = Category)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = Count), vjust = -0.2, size = 4) +  
  labs(title = "Comparison of Foreign Worker vs. No Known Savings",
       x = "Category",
       y = "Count") +
  scale_fill_manual(values = c("Foreign_Worker == 'yes'" = "lightgreen",  
                               "Statuses_Of_Savings == 'no known savings'" = "lightblue")) + 
  theme_minimal()  


# NEW Hypothesis
credit_6k = dataset[dataset$`Credit_Amount(RM)` <= 6000 & dataset$Class == "good",]
nrow(credit_6k)

summary(credit_6k$Age)
age_6k_40 = credit_6k[credit_6k$Age <= 60,]
nrow(age_6k_40)


foreign_6k_40_f = age_6k_40[age_6k_40$Foreign_Worker == "yes", ]
nrow(foreign_6k_40_f)

summary(factor(foreign_6k_40_f$`Status_of_Employment(year_range)`))
employ_6k_40_f_na = foreign_6k_40_f[foreign_6k_40_f$`Status_of_Employment(year_range)` != "unemployed", ]
nrow(employ_6k_40_f_na)


nrow(credit_6k)
nrow(age_6k_40)
nrow(foreign_6k_40_f)
nrow(employ_6k_40_f_na)