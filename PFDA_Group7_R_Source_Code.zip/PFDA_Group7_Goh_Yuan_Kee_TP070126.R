#Goh Yuan Kee - TP070126

library(ggplot2)
library(dplyr)

#Importing the .csv file
dataset = read.csv("C:\\Users\\User\\OneDrive - Asia Pacific University\\Desktop\\R\\5. credit_risk_classification.csv", header=TRUE)
dataset

#Renaming the first 6 columns' header
colnames(dataset)[1:6]=c("No.","Checking_Status","Duration(Year)","Credit_History","Purpose","Credit_Amount(RM)")
# renaming columns 7-11 (G-K)
names(dataset)[7:11] = 
  c("The_Statuses_of_Savings","Status_of_Employment(year_range)",
    "Installment_Commitment_Count","Confidential_Personal_Status",
    "Other_Party(type)")
# renaming columns 12-16 (L-P)
names(dataset)[12:16] = 
  c("Residence_Since","Property_Magnitude","Age","Other_Payment_Plans","Housing")
#renaming columns 17-22 (Q -V)
names(dataset)[17:22]=
  c("Existing_Credits","Job","Num_Dependents","Own_Telephone","Foreign_Worker","Class")
names(dataset)

colnames(dataset)

#Converting Duration(Year) column to hold only integer value
dataset$`Duration(Year)`=as.integer(dataset$`Duration(Year)`)
# convert to integer "Installment_Commitment_Count" (assignment_file[9])
dataset$Installment_Commitment_Count = as.integer(dataset$Installment_Commitment_Count)
# convert to integer "Residence_Since"
dataset$Residence_Since = as.integer(dataset$Residence_Since)
# convert to integer "Age"
dataset$Age = as.integer(dataset$Age)
#Existing_Credits = convert to integer 
dataset$Existing_Credits = as.integer(dataset$Existing_Credits)
# Num_Dependents = convert to integer
dataset$Num_Dependents = as.integer(dataset$Num_Dependents)


#Rounding the Credit_Amount(RM) column to 2 decimal places
dataset$`Credit_Amount(RM)`=round(dataset$`Credit_Amount(RM)`,2)
dataset$`Credit_Amount(RM)`

# fix the typo in Credit_History column ("no credits/all paid" -> "no credits")
dataset[dataset=="no credits/all paid"] = "no credits"
# fix the typo in the dataset ( "500<=X<10000" -> "500<=X<1000") to make it make sense :D
dataset[dataset=="500<=X<10000"] = "500<=X<1000"

# Function to get the mode
get_mode <- function(v) {
  uniq_v <- unique(v[!(is.na(v) | v == "")])  # Remove NA and blank spaces
  uniq_v[which.max(tabulate(match(v, uniq_v)))]  # Find the most frequent value
}
# Replace both NA values and blank spaces with the mode
dataset$Other_Payment_Plans[is.na(dataset$Other_Payment_Plans) | dataset$Other_Payment_Plans == ""] = get_mode(dataset$Other_Payment_Plans)

View(dataset)
str(dataset)

head(dataset)
tail(dataset)
names(dataset)
ncol(dataset)
nrow(dataset)
summary((dataset))

#Pre-processing column 2 - 6
factor(dataset$Checking_Status) #Categories in Checking_Status column
nlevels(factor(dataset$Checking_Status)) #Number of categories in Checking_Status column is 4
summary(dataset$`Duration(Year)`) #Summary of Duration(Year) column
factor(dataset$Credit_History) #Categories in Credit_History column
nlevels(factor(dataset$Credit_History)) #Number of categories in Credit_History column is 5
factor(dataset$Purpose) #Categories in Purpose column
nlevels(factor(dataset$Purpose)) #Number of categories in Purpose column is 10
summary(dataset$`Credit_Amount(RM)`) #Summary of Credit_Amount(RM) column

#Pre-processing column 12 - 16
summary(dataset$Residence_Since)
factor(dataset$Property_Magnitude)
nlevels(factor(dataset$Property_Magnitude))
summary(dataset$Age)
factor(dataset$Other_Payment_Plans)
nlevels(factor(dataset$Other_Payment_Plans))
factor(dataset$Housing)
nlevels(factor(dataset$Housing))

#Pre-processing column Q-V
summary(dataset$'Existing_Credits')#summary for Existing_Credits
factor(dataset$Job)
nlevels(factor(dataset$Job))
summary(dataset$'Num_Dependents')
factor(dataset$Own_Telephone)
nlevels(factor(dataset$Own_Telephone))
factor(dataset$Foreign_Worker)
nlevels(factor(dataset$Foreign_Worker))
factor(dataset$Class)
nlevels(factor(dataset$Class))

#column Q-V
#Customers with 1) low credit amount (0-4000), 2) long term employment(>=7), 3)no known savings,
#4) critical/order existing credit history tends to have a good credit score.
dataset[dataset$Class=="good", ]
nrow(dataset[dataset$Class=="good",] ) #3000


# The_Statuses_of_Savings (no known saving) under good class
savings_data <- dataset %>%
  filter(Class == "good") %>%
  group_by(The_Statuses_of_Savings) %>%
  summarise(count = n())

# Custom colors for each savings status level
custom_colors <- c(
  "no known savings" = "lightblue",
  "<100" = "lightcoral",
  "500<=X<1000" = "palegreen",
  "100<=X<500" = "lightgoldenrod",
  ">=1000" = "orchid"
)

# Pie chart for The_Statuses_of_Savings
savings_pie <- ggplot(savings_data, aes(x = "", y = count, fill = The_Statuses_of_Savings)) +
  geom_bar(width = 1, stat = "identity", color = "black") +
  coord_polar("y") +
  labs(title = "Savings Status in Good Credit Class (Pie Chart)", fill = "Savings Status") +
  geom_text(aes(label = paste(The_Statuses_of_Savings, ":", count)),
            position = position_stack(vjust = 0.5), size = 3, color = "black") +
  scale_fill_manual(values = custom_colors) +
  theme_void() +
  theme(legend.position = "right")
savings_pie




#credit history under class good 
# Filter dataset to include only "good" credit class and count occurrences of each Credit History type
credit_history_data <- dataset %>%
  filter(Class == "good") %>%
  count(Credit_History)

# View the count data to ensure it only includes the "good" class
print(credit_history_data)

# Bar chart for Credit History in Good Credit Score Class
credit_history_bar <- ggplot(credit_history_data, aes(x = Credit_History, y = n, fill = Credit_History)) +
  geom_bar(stat = "identity", width = 0.7, color = "black") +
  labs(title = "Credit History Distribution in Good Credit Score Class", x = "Credit History", y = "Count") +
  geom_text(aes(label = n), vjust = -0.3, color = "black") +  # Adds count labels above each bar
  scale_fill_manual(values = c(
    "critical/order existing credit" = "lightcoral",
    "existing paid" = "palegreen",
    "no credits" = "skyblue",
    "delayed" = "lightgoldenrod",
    "fully paid" = "orchid"
  )) +
  theme_minimal() +
  theme(legend.position = "none", axis.text.x = element_text(angle = 45, hjust = 1))
credit_history_bar




# Filter dataset to include only "good" credit class
good_credit_data <- dataset %>%
  filter(Class == "good") %>%
  mutate(Credit_Category = ifelse(`Credit_Amount(RM)` <= 4000, "<=4000", ">4000"))

# View the filtered data to ensure only "good" class data is included with categorized Credit Amounts
print(good_credit_data)

# Box plot for Credit Amount Distribution (<=4000 and >4000) in Good Credit Score Class
credit_amount_box <- ggplot(good_credit_data, aes(x = Credit_Category, y = `Credit_Amount(RM)`, fill = Credit_Category)) +
  geom_boxplot(color = "black", width = 0.5, outlier.colour = "red", outlier.shape = 16) +
  scale_fill_manual(values = c("<=4000" = "lightgreen", ">4000" = "lightblue")) +
  labs(title = "Credit Amount Distribution in Good Credit Score Class",
       x = "Credit Amount Category",
       y = "Credit Amount (RM)") +
  theme_minimal() +
  theme(legend.position = "none")
credit_amount_box







# Filter dataset to include only "good" credit class
good_data <- dataset %>%
  filter(Class == "good")

# Calculate the count of each employment status
employment_counts <- good_data %>%
  count(`Status_of_Employment(year_range)`) 

# Identify the employment status with the highest count
highest_status <- employment_counts %>%
  filter(n == max(n)) %>%
  pull(`Status_of_Employment(year_range)`)

# Create a dot plot for Employment Status with special styling for ">=7" and the highest count
employment_status_dot_plot <- ggplot(employment_counts, aes(x = n, y = `Status_of_Employment(year_range)`)) +
  geom_point(aes(size = n, color = ifelse(`Status_of_Employment(year_range)` == ">=7", "Long-term",
                                          ifelse(`Status_of_Employment(year_range)` == highest_status, "Most Frequent", "Other"))),
             alpha = 0.8) +
  scale_color_manual(values = c("Long-term" = "red", "Most Frequent" = "yellow", "Other" = "grey")) +
  scale_size_continuous(range = c(3, 8)) +
  labs(title = "Employment Status Distribution for Good Credit Class",
       x = "Frequency",
       y = "Employment Status (Year Range)",
       color = "Category") +
  theme_minimal() +
  theme(legend.position = "right")
employment_status_dot_plot


# Count the number of records that meet the criteria
nrow(dataset[(dataset$Class == "good") 
             & (dataset$The_Statuses_of_Savings == "<100") 
             & (dataset$Credit_History == "existing paid") 
             & (dataset$'Credit_Amount' <= 4000) 
             & (dataset$'Status_of_Employment' == "1<=X<4"), ]) #267



# Create a data frame for plotting
data_for_bar_chart <- data.frame(
  Category = c("Filtered Data (267)", "Other Data (5733)"),
  Count = c(267, 5733)  # Counts for filtered and other data
)

# Create the bar chart using ggplot2
bar_chart <- ggplot(data_for_bar_chart, aes(x = Category, y = Count, fill = Category)) +
  geom_bar(stat = "identity", color = "black") +  # Create bars
  labs(title = "Comparison of Filtered Data vs Other Data", 
       x = "Category", 
       y = "Count") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),  # Center the title
    legend.position = "none"  # Remove legend
  ) +
  scale_fill_manual(values = c("Filtered Data (267)" = "red", "Other Data (5733)" = "lightblue"))

# Display the bar chart
print(bar_chart)




#caculate the %  additional part
# Create a data frame for plotting
data_for_bar_chart <- data.frame(
  Category = c("Filtered Data (267)", "Other Data (5733)"),
  Count = c(267, 5733)  # Counts for filtered and other data
)

# Calculate the total count
total_count <- sum(data_for_bar_chart$Count)

# Calculate the percentage for each category
data_for_bar_chart$Percentage <- (data_for_bar_chart$Count / total_count) * 100

# Print the updated data frame with percentages
print(data_for_bar_chart)

# Check if the percentages sum to 100
percentage_sum <- sum(data_for_bar_chart$Percentage)
cat("Sum of Percentages: ", percentage_sum, "%\n")



# Count the number of records that meet the criteria
nrow(dataset[(dataset$Class == "good") 
             & (dataset$'Job' == "skilled"), ]) #1893

# Count the number of records that meet the criteria
nrow(dataset[(dataset$Class == "good") 
             & (dataset$'Housing' == "own"), ]) #2282

# Count the number of records that meet the criteria
nrow(dataset[(dataset$Class == "good") 
             & (dataset$'Job' == "skilled")
             & (dataset$'Housing' == "own"), ])#1477
  
             






colnames(dataset)


#Good
#Credit amount <= 6000 
#Age <= 60
#Foreign worker == yes
#Status of Employment != Unemployed



# Count the number of records that meet the criteria
count <- nrow(dataset[(dataset$Class == "good")
                      & (dataset$`Credit_Amount(RM)` <= 6000)
                      & (dataset$`Age` <= 60)
                      & (dataset$Foreign_Worker == "yes")
                      & (dataset$`Status_of_Employment(year_range)` != "unemployed"),])

print(count)


# Data frame for the bar chart
data_for_bar_chart <- data.frame(
  Category = c("Filtered Data", "Other Data"),
  Count = c(count, nrow(dataset) - count)
)

# Create the bar chart with ggplot2
library(ggplot2)
bar_chart <- ggplot(data_for_bar_chart, aes(x = Category, y = Count, fill = Category)) +
  geom_bar(stat = "identity", color = "black") +
  labs(title = "Comparison of Filtered Data vs Other Data", 
       x = "Category", 
       y = "Count") +
  scale_fill_manual(values = c("Filtered Data" = "red", "Other Data" = "lightblue")) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    legend.position = "none"
  )

# Display the bar chart
print(bar_chart)


#Final Conclusion
final_conclusion = nrow(good[(good$`Credit_Amount(RM)`<=6000) & 
                               (good$Age <= 60) &
                               (good$Foreign_Worker == "yes") & 
                               (good$`Status_of_Employment(year_range)`!= "unemployed"), ])
final_conclusion

#Venn Diagram for final conclusion
draw.pairwise.venn(
  area1 = 3000,         # Total "good" class
  area2 = final_conclusion,
  cross.area = final_conclusion,
  category = c("Total Good Class", "Final Conclusion"),
  fill = c("lightgreen", "blue"),
  lty = "blank",
  cex = 2, cat.cex = 1.5, cat.pos = c(-20, 20), cat.dist = 0.02, scaled = TRUE
)








