#Valen Christino - TP072897

#Importing the .csv file
dataset = read.csv("D:\\School\\APU\\PFDA - R programming\\credit_risk.csv", header=TRUE)
dataset

#Renaming the first 6 columns' header
colnames(dataset)[1:6]=c("No.","Checking_Status","Duration(Year)","Credit_History","Purpose","Credit_Amount(RM)")
# renaming columns 7-11 (G-K)
names(dataset)[7:11] = 
  c("The_Statuses_of_Savings","Status_of_Employment(year_range)",
    "Installment_Commitment_Count","Confidential_Personal_Status",
    "Other_Party(type)")
# renaming columns 12-16 (L-P)
names(dataset)[12:16] = 
  c("Residence_Since","Property_Magnitude","Age","Other_Payment_Plans","Housing")
#renaming columns 17-22 (Q -V)
names(dataset)[17:22]=
  c("Existing_Credits","Job","Num_Dependents","Own_Telephone","Foreign_Worker","Class")
names(dataset)

#Converting Duration(Year) column to hold only integer value
dataset$`Duration(Year)`=as.integer(dataset$`Duration(Year)`)
# convert to integer "Installment_Commitment_Count" (assignment_file[9])
dataset$Installment_Commitment_Count = as.integer(dataset$Installment_Commitment_Count)
# convert to integer "Residence_Since"
dataset$Residence_Since = as.integer(dataset$Residence_Since)
# convert to integer "Age"
dataset$Age = as.integer(dataset$Age)
#Existing_Credits = convert to integer 
dataset$Existing_Credits = as.integer(dataset$Existing_Credits)
# Num_Dependents = convert to integer
dataset$Num_Dependents = as.integer(dataset$Num_Dependents)


#Rounding the Credit_Amount(RM) column to 2 decimal places
dataset$`Credit_Amount(RM)`=round(dataset$`Credit_Amount(RM)`,2)
dataset$`Credit_Amount(RM)`

# fix the typo in Credit_History column ("no credits/all paid" -> "no credits")
dataset[dataset=="no credits/all paid"] = "no credits"
# fix the typo in the dataset ( "500<=X<10000" -> "500<=X<1000") to make it make sense :D
dataset[dataset=="500<=X<10000"] = "500<=X<1000"

# Function to get the mode
get_mode <- function(v) {
  uniq_v <- unique(v[!(is.na(v) | v == "")])  # Remove NA and blank spaces
  uniq_v[which.max(tabulate(match(v, uniq_v)))]  # Find the most frequent value
}
# Replace both NA values and blank spaces with the mode
dataset$Other_Payment_Plans[is.na(dataset$Other_Payment_Plans) | dataset$Other_Payment_Plans == ""] = get_mode(dataset$Other_Payment_Plans)

View(dataset)
str(dataset)

head(dataset)
tail(dataset)
names(dataset)
ncol(dataset)
nrow(dataset)
summary((dataset))

#Pre-processing column 2 - 6
factor(dataset$Checking_Status) #Categories in Checking_Status column
nlevels(factor(dataset$Checking_Status)) #Number of categories in Checking_Status column is 4
summary(dataset$`Duration(Year)`) #Summary of Duration(Year) column
factor(dataset$Credit_History) #Categories in Credit_History column
nlevels(factor(dataset$Credit_History)) #Number of categories in Credit_History column is 5
factor(dataset$Purpose) #Categories in Purpose column
nlevels(factor(dataset$Purpose)) #Number of categories in Purpose column is 10
summary(dataset$`Credit_Amount(RM)`) #Summary of Credit_Amount(RM) column




# analysis of original hypothesis

# credit amount analysis
`Credit<=4000` = dataset[dataset$`Credit_Amount(RM)` <= 4000 & dataset$Class=="good",]
nrow(`Credit<=4000`)
# decrease to 2406


# employment analysis
employ_1 = `Credit<=4000`[`Credit<=4000`$`Status_of_Employment(year_range)`=="unemployed",]
employ_2 = `Credit<=4000`[`Credit<=4000`$`Status_of_Employment(year_range)`=="<1",]
employ_3 = `Credit<=4000`[`Credit<=4000`$`Status_of_Employment(year_range)`=="1<=X<4",]
employ_4 = `Credit<=4000`[`Credit<=4000`$`Status_of_Employment(year_range)`=="4<=X<7",]
employ_5 = `Credit<=4000`[`Credit<=4000`$`Status_of_Employment(year_range)`==">=7",]

nrow(employ_1) #110
nrow(employ_2) #359
nrow(employ_3) #832
nrow(employ_4) #437
nrow(employ_5) #668


# both still good continue to savings status
'savings_3_<=4000_1' = employ_3[employ_3$The_Statuses_of_Savings == "no known savings", ] # 115
'savings_3_<=4000_2' = employ_3[employ_3$The_Statuses_of_Savings == "<100", ]             # 483
'savings_3_<=4000_3' = employ_3[employ_3$The_Statuses_of_Savings == "100<=X<500", ]       # 79
'savings_3_<=4000_4' = employ_3[employ_3$The_Statuses_of_Savings == "500<=X<1000", ]      # 84
'savings_3_<=4000_5' = employ_3[employ_3$The_Statuses_of_Savings == ">=1000", ]           # 71

nrow(`savings_3_<=4000_1`)
nrow(`savings_3_<=4000_2`)
nrow(`savings_3_<=4000_3`)
nrow(`savings_3_<=4000_4`)
nrow(`savings_3_<=4000_5`)


'savings_5_<=4000_1' = employ_5[employ_5$The_Statuses_of_Savings == "no known savings", ] # 217
'savings_5_<=4000_2' = employ_5[employ_5$The_Statuses_of_Savings == "<100", ]             # 268
'savings_5_<=4000_3' = employ_5[employ_5$The_Statuses_of_Savings == "100<=X<500", ]       # 73
'savings_5_<=4000_4' = employ_5[employ_5$The_Statuses_of_Savings == "500<=X<1000", ]      # 71
'savings_5_<=4000_5' = employ_5[employ_5$The_Statuses_of_Savings == ">=1000", ]           # 39

nrow(`savings_5_<=4000_1`)
nrow(`savings_5_<=4000_2`)
nrow(`savings_5_<=4000_3`)
nrow(`savings_5_<=4000_4`)
nrow(`savings_5_<=4000_5`)


# savings_3<=4000_2 has the highest share of the split so we take this one
credit_history_1 = `savings_3_<=4000_2`[`savings_3_<=4000_2`$Credit_History == "critical/order existing credit",]
credit_history_2 = `savings_3_<=4000_2`[`savings_3_<=4000_2`$Credit_History == "existing paid",]
credit_history_3 = `savings_3_<=4000_2`[`savings_3_<=4000_2`$Credit_History == "delayed previously" ,]
credit_history_4 = `savings_3_<=4000_2`[`savings_3_<=4000_2`$Credit_History == "no credits" ,]
credit_history_5 = `savings_3_<=4000_2`[`savings_3_<=4000_2`$Credit_History == "all paid",]

nrow(credit_history_1) # 131
nrow(credit_history_2) # 267
nrow(credit_history_3) # 55
nrow(credit_history_4) # 15
nrow(credit_history_5) # 15

# the majority falls on credit history 2
# this is the result of the filters : 267
#         credit amount <= 4000
#         employment 1<=X<4
#         saving status < 100
#         credit history = "existing paid"



# new conclusion
credit_6k = dataset[dataset$`Credit_Amount(RM)` <= 6000 & dataset$Class == "good",]
nrow(credit_6k)

summary(credit_6k$Age)
age_6k_40 = credit_6k[credit_6k$Age <= 60,]
nrow(age_6k_40)


foreign_6k_40_f = age_6k_40[age_6k_40$Foreign_Worker == "yes", ]
nrow(foreign_6k_40_f)

summary(factor(foreign_6k_40_f$`Status_of_Employment(year_range)`))
employ_6k_40_f_na = foreign_6k_40_f[foreign_6k_40_f$`Status_of_Employment(year_range)` != "unemployed", ]
nrow(employ_6k_40_f_na)


nrow(credit_6k)
nrow(age_6k_40)
nrow(foreign_6k_40_f)
nrow(employ_6k_40_f_na)

# summary of new conclusion:
#       credit amount <= 6000
#       the first filter gets the majority of the dataset with 2652 rows  ~ 88.4% of data
#
#       age <= 60 
#       with this we cut the dataset to 2512 with an overwhelming majority ~ 83.73% of data 
#
#       foreign worker == "yes"
#       now we have quite a bit less with 2387 rows ~ 79.56% of data
#
#       employment != "unemployed"
#       excluding the unemployed rows, we get 2294 rows ~ 76.46% of data
#
#   The new Conclusion consists of :  people who has credit amount <=6000, age is <= 60, 
#     is a foreign worker, and is not unemployed
#
#   This new conclusion is most accurate on the 2nd and 4th filters since we lose very little data samples while 
#   applying these filters around ~5% and ~3% respectively.




# graphs for our original hypothesis
install.packages("ggplot2")
install.packages("dplyr")
install.packages("ggrepel")
install("hexbin")
library(hexbin)
library(ggplot2)
library(dplyr)
library(ggrepel)

# graph 1 violin graph of credit amount on good credit score
summary_credit = dataset %>%
  group_by(Class) %>%
  summarise(
    min_age = min(`Credit_Amount(RM)`, na.rm = TRUE),
    q1_age = quantile(`Credit_Amount(RM)`, 0.25, na.rm = TRUE),
    median_age = median(`Credit_Amount(RM)`, na.rm = TRUE),
    q3_age = quantile(`Credit_Amount(RM)`, 0.75, na.rm = TRUE),
    max_age = max(`Credit_Amount(RM)`, na.rm = TRUE),
    .groups = 'drop'   )

ggplot(dataset, aes(x = Class, y = `Credit_Amount(RM)`)) + 
  geom_violin(trim = TRUE, fill = "yellow") +
  geom_boxplot(width = 0.1, aes(fill = Class)) +
  geom_text(data = summary_credit, aes(x = Class, y = min_age, label = round(min_age, 1)), 
            vjust = -0.5, color = "blue") +
  geom_text(data = summary_credit, aes(x = Class, y = q1_age, label = round(q1_age, 1)), 
            vjust = -0.5, color = "blue") +
  geom_text(data = summary_credit, aes(x = Class, y = median_age, label = round(median_age, 1)), 
            vjust = -0.5, color = "blue") +
  geom_text(data = summary_credit, aes(x = Class, y = q3_age, label = round(q3_age, 1)), 
            vjust = -0.5, color = "blue") +
  geom_text(data = summary_credit, aes(x = Class, y = max_age, label = round(max_age, 1)), 
            vjust = -0.5, color = "blue") +
  ggtitle("Credit Amount Violin graph")



# from this graph we can see that good customers often have less Credit Amount
# showing the most likely range for good customers to be 1360-3632 RM



# employment
# Filter the dataset for Class "good"
good_data = filter(dataset, Class == "good") 

# Create a new variable 'Objective1' based on the objective
mutated_data = mutate(good_data, Credit_Category = ifelse(`Credit_Amount(RM)` <= 4000, 
                                                          "not more than 4000", 
                                                          "More than 4000"))
# summarize data 
credit_employment = summarise(
  group_by(mutated_data, Credit_Category, `Status_of_Employment(year_range)`), 
  Count = n(), .groups = 'drop')


ggplot(credit_employment, aes(x = `Status_of_Employment(year_range)`, y = Count, fill = Credit_Category)) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("not more than 4000" = "green", "More than 4000" = "brown")) +
  labs(title = "Stacked Bar Chart of Class by Employment",
       x = "Credit History",
       y = "Count") +
  geom_text(data = credit_employment, 
            aes(label = round(Count, 1)),
            position = position_stack(vjust = 0.5),
            size = 3.5,
            color = "red",
            fontface = "bold")


# savings 

good_data_after_credit_amount = filter(dataset, Class == "good", `Credit_Amount(RM)` <= 4000) 
good_data_after_employment_and_credit_amount = 
  filter(good_data_after_credit_amount, `Status_of_Employment(year_range)` == ">=7" |
           `Status_of_Employment(year_range)` == "1<=X<4")


# summarize the newly filtered data
credit_employment_savings <- good_data_after_employment_and_credit_amount %>%
  group_by(The_Statuses_of_Savings, `Status_of_Employment(year_range)`) %>%
  summarise(count = n(), .groups = 'drop')


ggplot(credit_employment_savings, aes(x = The_Statuses_of_Savings, y = count, fill = `Status_of_Employment(year_range)`)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = "Stacked Bar Chart of Savings",
       x = "Savings Status",
       y = "Count") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))+
  geom_text(data = credit_employment_savings, 
            aes(label = round(count, 1)),
            position = position_dodge(w = 0.9),
            vjust = -0.5,
            size = 3.5,
            color = "red",
            fontface = "bold")



# credit history

good_data_after_employment_credit_amount_and_savings = 
  filter(good_data_after_credit_amount, 
         `Status_of_Employment(year_range)` == "1<=X<4",
         The_Statuses_of_Savings == "<100"
  )

credit_employment_savings_history <- good_data_after_employment_credit_amount_and_savings %>%
  group_by(Credit_History) %>%
  summarise(count = n(), .groups = 'drop')

ggplot(credit_employment_savings_history, aes(x = "", y = count, fill = Credit_History)) +
  geom_bar(stat = "identity", width = 1) +
  geom_label_repel(aes(label = paste(Credit_History, ":", count)),
                   position = position_stack(vjust = 0.5),
                   show.legend = FALSE)+
  coord_polar("y") +  # Convert bar chart to pie chart
  labs(title = "Credit History Distribution") +
  theme_void() 




# Group Part
# graph for new credit amount in new conclusion
Credit_Amount_data_new = mutate(good_data, Credit_Category = 
                                  ifelse(`Credit_Amount(RM)` <= 6000,
                                         "not more than 6000","more than 6000"))
# summarize data 
credit_new = summarise(
  group_by(Credit_Amount_data_new, Credit_Category), 
  Count = n(), .groups = 'drop')

ggplot(credit_new, aes(x = "", y = Count, fill = Credit_Category)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar("y") +  # Convert bar chart to pie chart
  labs(title = "New Credit Amount Distribution") +
  scale_fill_manual(values = c("not more than 6000" = "green",
                               "more than 6000" = "red")) +
  geom_label_repel(aes(label = paste(Count)),
                   position = position_stack(vjust = 0.5),
                   show.legend = FALSE)+
  theme_void()



# graph for credit amount in original hypothesis
Credit_Amount_data_old = mutate(good_data, Credit_Category = 
                                  ifelse(`Credit_Amount(RM)` <= 4000,
                                         "not more than 4000","more than 4000"))
# summarize data
credit_old = summarise(
  group_by(Credit_Amount_data_old, Credit_Category), 
  Count = n(), .groups = 'drop')

ggplot(credit_old, aes(x = "", y = Count, fill = Credit_Category)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar("y") +  # Convert bar chart to pie chart
  labs(title = "Old Credit Amount Distribution") +
  scale_fill_manual(values = c("not more than 4000" = "green", "more than 4000" = "red")) +
  geom_label_repel(aes(label = paste(Count)),
                   position = position_stack(vjust = 0.5),
                   show.legend = FALSE)+
  theme_void()






# additional analysis


# graph 3 clustered bar graph checking status
summary_checking <- dataset %>%
  group_by(Checking_Status, Class) %>%
  summarise(count = n(), .groups = 'drop')

ggplot(summary_checking, aes(x = Checking_Status, y = count, fill = Class)) +
  geom_bar(stat = "identity", position = "dodge") + 
  scale_fill_manual(values = c("bad" = "black", "good" = "yellow")) +
  geom_text(data = summary_checking, 
            aes(x = Checking_Status, y = count, label = round(count, 1)),
            position = position_dodge(w = 0.9),
            vjust = -0.5,
            size = 3.5,
            color = "blue",
            fontface = "bold")


# age to duration of employment using geom_hex
summary_age_duration = summarise(
  group_by(good_data, Age, `Duration(Year)`),
  Count = n(), .groups = 'drop'
)

ggplot(summary_age_duration, aes(x = Age, y = `Duration(Year)`)) +
  geom_hex(bins = 30) +  # You can adjust the number of bins
  scale_fill_gradient(low = "yellow", high = "red") +  
  labs(title = "Hexagonal Binning Plot Age to Duration of good credit score",
       x = "Age",
       y = "Duration in years",
       fill = "Count") +  # Legend title
  theme_minimal() 


# purpose piechart 
slices_g = table(dataset$Purpose[dataset$Class == "good"])
pie (slices_g, labels = paste(dataset$Purpose, slices_g),
     main = "Purpose pie chart",
     clockwise = FALSE)






